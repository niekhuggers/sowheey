/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configuration for mobile testing
}

module.exports = nextConfig